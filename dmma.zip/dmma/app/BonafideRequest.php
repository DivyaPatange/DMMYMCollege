<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BonafideRequest extends Model
{
    protected $table = 'bonafide_requests';
    protected $fillabe = ['user_id','request'];
}
