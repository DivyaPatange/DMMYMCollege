<?php
namespace app;

/**
* class TXTLCL to send SMS on Mobile Numbers.
* @author Shashank Tiwari
*/
class TXTLCL {

    function __construct() {

    }

    private $username = "bawane20samruddhi@gmail.com";
    private $API_KEY = '94f8f111f3d9bed8b6bf46e43e0db4f42b9833626e1d7278cd6fd75f14258c7f';
    // private $SENDER_ID = "VERIFY";
    // private $ROUTE_NO = 4;
    private $RESPONSE_TYPE = 'json';
    //Config variables. Consult http://api.textlocal.in/docs for more info.
    private $test = "0";
    // Data for text message. This is the text message data.
	private $sender = "TXTLCL"; // This is who the message appears to be from.

    public function sendSMS($OTP, $mobileNumber){
        $isError = 0;
        $errorMessage = true;

        //Your message to send, Adding URL encoding.
        $message = urlencode("Welcome to Vimladevi , Your OPT is : $OTP");
        
        //Preparing post parameters
        $postData = array(
            'authkey' => '94f8f111f3d9bed8b6bf46e43e0db4f42b9833626e1d7278cd6fd75f14258c7f',
            'mobiles' => $mobileNumber,
            'message' => $message,
            'username' => 'bawane20samruddhi@gmail.com' ,
            //'route' => $this->ROUTE_NO,
            'response' => $this->RESPONSE_TYPE
        );

        $url = "http://api.textlocal.in/send/?";
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData
        ));
        //Ignore SSL certificate verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
     
     
        //get response
        $output = curl_exec($ch);
     
        //Print error if any
        if (curl_errno($ch)) {
            $isError = true;
            $errorMessage = curl_error($ch);
        }
        curl_close($ch);
        if($isError){
            return array('error' => 1 , 'message' => $errorMessage);
        }else{
            return array('error' => 0 );
        }
    }
}
?>