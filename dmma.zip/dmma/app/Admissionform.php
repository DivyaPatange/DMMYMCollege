<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admissionform extends Model
{
    protected $table = 'admissionforms';
    protected $fillabe = ['user_id','formno','academicyear','course','subject','admissionyear',
    'admissiondate','admittedcategory','firstname','middlename','lastname','fathername','fatheroccu',
    'mothername','motheroccu','dob','birthcity','birthdistrict','birthstate','nationality','religion','caste',
    'castecategory','gender','uid','voterid','presentaddress','presentcity','presentstate','permanentaddress','permanentcity',
    'permanentstate','studcontact','studemail','fathercontact','fatheremail','mothercontact','maotheremail','lastclgattended',
    'clgstate','clgcity','twelvethboard','passingyear','seatno','certificateno','percentage','aggregate','physicsmarks','chemistrymarks',
    'biologymarks','neetmarksobtained','neetoutoff','neetyear','quotaalloted','scheme','dirsecyear','clgaddress','clgcode',
    'obtainedmarks','totalmarks','previousyearresult','previousexampercentage'];
}
