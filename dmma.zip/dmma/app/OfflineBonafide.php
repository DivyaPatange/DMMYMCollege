<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OfflineBonafide extends Model
{
    protected $table = 'offline_bonafides';
    protected $fillable = ['fullname','fathername','class','academicyear','admissiondate','dob','dobtext','date'];

}
