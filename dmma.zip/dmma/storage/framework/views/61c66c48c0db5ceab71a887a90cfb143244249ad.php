

<?php $__env->startSection('title','Bonafide Certificate request'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       .hidden{
           display:none;
       }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
    <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">	
                    <strong><?php echo e($message); ?></strong>
            </div>
    <?php endif; ?>
 <form action="<?php echo e(route('bonafideCertificate.reqBonafide')); ?>" enctype="multipart/form-data" method="post"> 
     <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
    
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Request For Bonafide Certificate</h6>
        <div class="mdc-layout-grid__cell stretch-card1 mdc-layout-grid__cell--span-12-desktop text-center">
          <?php 
              use Illuminate\Support\Facades\DB;
              use Illuminate\Support\Facades\Auth;
              $req=DB::table('bonafide_requests')->where('user_id',Auth::user()->id)->first();
              //dd($req);
              ?>
            <button class="mdc-button mdc-button--unelevated filled-button--success mdc-ripple-upgraded" style="--mdc-ripple-fg-size:56px; --mdc-ripple-fg-scale:1.96936; --mdc-ripple-fg-translate-start:6px, -0.200012px; --mdc-ripple-fg-translate-end:18.8px, -10px;" type="submit" name="submit"<?php if(!empty($req)): ?> <?php if($req->request == 1): ?> disabled <?php endif; ?> <?php endif; ?>>
              
              <?php if(!empty($req)): ?>
                <?php if($req->request == 1): ?> Requested

                <?php endif; ?> 
                <?php else: ?> Request 
            <?php endif; ?>
            </button>
          </div>
            <br>
            <br> 
      </div>
    </div>
  </div>
 </form> 
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.student_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\demonstration\resources\views/students/bonafideCertificateRequest.blade.php ENDPATH**/ ?>