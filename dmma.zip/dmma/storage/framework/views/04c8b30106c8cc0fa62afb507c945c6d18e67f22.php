<script src="<?php echo e(asset('brandAssets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo e(asset('brandAssets/vendors/chartjs/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('brandAssets/vendors/jvectormap/jquery-jvectormap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('brandAssets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(asset('brandAssets/js/material.js')); ?>"></script>
  <script src="<?php echo e(asset('brandAssets/js/misc.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('brandAssets/js/dashboard.js')); ?>"></script>
  <!-- End custom js for this page-->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
    $(document).ready(function() {
        $('#datatable').DataTable();
    } );
    </script>
    <script>
    $(document).ready(function() {
        $('#datatable1').DataTable();
    } );
    </script>
         <!-- //data table -->
    <!--  -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

 
 <?php /**PATH G:\wamp64\www\laravel\dmma\resources\views/admin/admin_layouts/scripts.blade.php ENDPATH**/ ?>