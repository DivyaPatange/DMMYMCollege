<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>VAMC | <?php echo $__env->yieldContent('title'); ?></title>
  <!-- plugins:css -->
  <?php echo $__env->make('students.student_layouts.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('customcss'); ?>
</head>
<body>
<script src="<?php echo e(asset('brandAssets/js/preloader.js')); ?>"></script>
  <div class="body-wrapper">
    <!-- partial:partials/_sidebar.html -->
    <?php echo $__env->make('students.student_layouts.studSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- partial -->
    <div class="main-wrapper mdc-drawer-app-content">
      <!-- partial:partials/_navbar.html -->
      <?php echo $__env->make('students.student_layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <div class="page-wrapper mdc-toolbar-fixed-adjust">
        <main class="content-wrapper">
          <?php echo $__env->yieldContent('content'); ?>
        </main>
        <!-- partial:partials/_footer.html -->
        <?php echo $__env->make('students.student_layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <?php echo $__env->make('students.student_layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('customjs'); ?>
</body>
</html> <?php /**PATH G:\wamp64\www\laravel\demonstration\resources\views/students/student_layouts/main.blade.php ENDPATH**/ ?>