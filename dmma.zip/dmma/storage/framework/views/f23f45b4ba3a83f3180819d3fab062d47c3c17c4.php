<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>VAMC | Student Profile</title>
  <!-- plugins:css -->
  <style>
    .hidden{
        display:none;
    }
 </style>
  <?php echo $__env->make('admin.admin_layouts.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
  <script src="<?php echo e(asset('brandAssets/js/preloader.js')); ?>"></script>
    <div class="body-wrapper">
      <div class="page-wrapper mdc-toolbar-fixed-adjust">
        <main class="content-wrapper">
<div class="mdc-layout-grid">

    
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">

<div class="container">
  <div class="row p-4">
  <center>
  <table style="border-bottom: 2px double; width: 100%;" >
      <tr>
        <td rowspan="4"><img src="<?php echo e(asset('brandAssets/images/logo/vimladevi_logo.png')); ?>" style="width:100px;" alt="logo"></td>
      </tr>
      <tr>
        <td style="text-align: center;"><h4>SHRI GURUKRIPA SHIKSHAN PRASARAK MANDAL'S</h4></td>
      </tr>
      <tr>
        <td style="text-align: center;"><h3><b>SMT. VIMLADEVI AYURVEDIC MEDICAL COLLEGE & HOSPITAL<br>At. Wandhari, Dist. Chandrapur.</b></h3></td>
      </tr>
      <tr>
        <td style="text-align: center;"><h5><b>(Affiliated to M.U.H.S Nashik, Approved by C.C.I.M. & AUYSH, New Delhi)</b></h5></td>
      </tr>
     </table>
     </center>
     <center>
     <table style="width: 100%;" class="table-bordered">
    <tbody>
    <tr>
      <td class="text-center" colspan="4" style="border-bottom: 2px double; padding: 10px;"><h5><b> Admission Form</b></h5></td>
      </tr>
      <tr>
      <td style="width: 309px; padding:1px;"><b>From No.:</b> <?php echo e($admissionform->formno); ?></td>
        <td><b>Academic Year:</b> <?php echo e($admissionform->academicyear); ?></td>
        <td><b>Course:</b> <?php echo e($admissionform->course); ?></td>
        <td><b>Subject.:</b> <?php echo e($admissionform->subject); ?></td>
      </tr>
      <tr>
        
        <td><b>Admission Year:</b> <?php echo e($admissionform->admissionyear); ?></td>
      <td><b>Admission Date:</b> <?php echo e($admissionform->admissiondate); ?></td>
        <td><b>Admitted Category:</b> <?php echo e($admissionform->admittedcategory); ?></td>
        <td></td>
      </tr>
      <tr>
      <td class="text-center" colspan="4" style="border-bottom: 1px double; padding: 10px;"><b> Personal Details</b><br></td>
      </tr>
      <tr>
      <td colspan="4"><br><b>Full Name: </b><?php echo e($admissionform->firstname); ?>&nbsp;<?php echo e($admissionform->middlename); ?>&nbsp;<?php echo e($admissionform->lastname); ?></td>
      </tr>
      
      <tr>
        <td><b>Father's Name: </b> <?php echo e($admissionform->fathername); ?></td>
        <td><b>father's Occupation: </b> <?php echo e($admissionform->fatheroccu); ?></td>
        <td><b>Mother's Name: </b><?php echo e($admissionform->mothername); ?></td>
        <td><b>Mother's Occupation: </b> <?php echo e($admissionform->motheroccu); ?></td>
      </tr>
      <tr>
        <td><b>DOB: </b> <?php echo e($admissionform->dob); ?></td>
        <td><b>City of Birth</b> <?php echo e($admissionform->birthcity); ?></td>
        <td><b>District of Birth:</b><?php echo e($admissionform->birthdistrict); ?></td>
        <td><b>State of Birth:</b> <?php echo e($admissionform->birthstate); ?></td>
      </tr>
      <tr>
        <td><b>Nationality: </b> <?php echo e($admissionform->nationality); ?></td>
        <td><b>Religion: </b> <?php echo e($admissionform->religion); ?></td>
        <td><b>Caste: </b><?php echo e($admissionform->caste); ?></td>
        <td><b>Caste Category:</b> <?php echo e($admissionform->castecategory); ?></td>
      </tr>
      <tr>
        <td><b>Gender: </b> <?php echo e($admissionform->gender); ?></td>
          <td style="text-align: center;" colspan="2"><b>UID: </b> <?php echo e($admissionform->uid); ?></td>
          <td><b>Voter Id: </b><?php echo e($admissionform->voterid); ?></td>
      </tr>
      <tr>
        <td class="text-center" colspan="4" style="border-bottom: 1px double; padding: 10px; "><b> Address Details</b></td>
      </tr>
      <tr>
        <td colspan="4"><br><b>Present Address: </b> <?php echo e($admissionform->presentaddress); ?></td>
      </tr>
      <tr>
      <td Colspan="2"><b>Present City: </b> <?php echo e($admissionform->presentcity); ?></td>
        <td Colspan="2"><b>Present State: </b> <?php echo e($admissionform->presentstate); ?></td>
      </tr>
      <tr>
        <td colspan="4"><b>Permanent Address: </b> <?php echo e($admissionform->permanentaddress); ?></td>
      </tr>
      <tr>
        <td Colspan="2"><b>Permanent City: </b> <?php echo e($admissionform->permanentcity); ?></td>
        <td Colspan="2"><b>Permanent State: </b> <?php echo e($admissionform->permanentstate); ?></td>
      </tr>
      <tr>
        <td Colspan="2"><b>Student Contact No: </b> <?php echo e($admissionform->studcontact); ?></td>
      <td Colspan="2"><b>Student Email: </b> <?php echo e($admissionform->studemail); ?></td>
      </tr>
      <tr>
        <td Colspan="2"><b>Father's Contact No: </b> <?php echo e($admissionform->fathercontact); ?></td>
        <td Colspan="2"><b>Father's Email: </b> <?php echo e($admissionform->fatheremail); ?></td>
      </tr>
      <tr>
        <td Colspan="2"><b>Mother's Contact No.: </b> <?php echo e($admissionform->mothercontact); ?></td>
        <td Colspan="2"><b>Mother's Email: </b> <?php echo e($admissionform->maotheremail); ?></td>
      </tr>
      <tr>
        <td class="text-center" colspan="4" style="border-bottom: 1px double; padding: 10px;"><b> Last School Details</b></td>
      </tr>
      <tr>
        <td><br><b>Last College Attended: </b> <?php echo e($admissionform->lastclgattended); ?></td>
          <td style="text-align: center;" colspan="2"><b>College City: </b> <?php echo e($admissionform->clgcity); ?></td>
          <td><b>College state: </b><?php echo e($admissionform->clgstate); ?></td>
      </tr>
      <tr>
        <td class="text-center" colspan="4" style="border-bottom: 1px double; padding: 10px; "><b> HSSC Details</b></td>
      </tr>
      <tr>
        <td><br><b>12th Board: </b> <?php echo e($admissionform->twelvethboard); ?></td>
          <td style="text-align: center;" colspan="2"><b>Passing Year: </b> <?php echo e($admissionform->passingyear); ?></td>
          <td><b>Seat No.: </b><?php echo e($admissionform->seatno); ?></td>
      </tr>
      <tr>
          <td><b>Certificate No.: </b> <?php echo e($admissionform->certificateno); ?></td>
          <td style="text-align: center;" colspan="2"><b>Percentage: </b> <?php echo e($admissionform->percentage); ?></td>
          <td><b>Aggregate: </b><?php echo e($admissionform->aggregate); ?></td>
      </tr>
      <tr>
          <td><b>Physics Marks: </b> <?php echo e($admissionform->physicsmarks); ?></td>
          <td style="text-align: center;" colspan="2"><b>Chemistry Marks: </b> <?php echo e($admissionform->chemistrymarks); ?></td>
          <td><b>Biology Marks : </b><?php echo e($admissionform->biologymarks); ?></td>
      </tr>
      <tr>
        <td class="text-center" colspan="4" style="border-bottom: 1px double; padding: 10px; "><b> NEET Exam Details</b></td>
      </tr>
      <tr>
        <td><br><b>NEET Marks obtained: </b> <?php echo e($admissionform->neetmarksobtained); ?></td>
          <td style="text-align: center;" colspan="2"><b>NEET Marks out off: </b> <?php echo e($admissionform->neetmarksoutoff); ?></td>
          <td><b>NEET Year: </b><?php echo e($admissionform->neetyear); ?></td>
      </tr>
      <tr>
          <td><b>Quota alloted: </b> <?php echo e($admissionform->quotaalloted); ?></td>
          <td style="text-align: center;" colspan="2"><b>Scheme: </b> <?php echo e($admissionform->scheme); ?></td>
          <td><b>Direct Sec year: </b><?php echo e($admissionform->dirsecyear); ?></td>
      </tr>
      <tr>
        <td class="text-center" colspan="4" style="border-bottom: 1px double; padding: 10px; "><b> Previous Exam Details</b></td>
      </tr>
      <tr>
        <td><br><b>College Address: </b> <?php echo e($admissionform->clgaddress); ?></td>
          <td style="text-align: center;" colspan="2"><b>College Code: </b> <?php echo e($admissionform->clgcode); ?></td>
          <td><b>Obtained Marks: </b><?php echo e($admissionform->obtainedmarks); ?></td>
      </tr>
      <tr>
          <td><b>Total Marks </b> <?php echo e($admissionform->totalmarks); ?></td>
          <td style="text-align: center;" colspan="2"><b>Previous Year Result: </b> <?php echo e($admissionform->previousyearresult); ?></td>
          <td><b>Previous Exam Percentage: </b><?php echo e($admissionform->previousexampercentage); ?></td>
      </tr>
      <?php
      use Illuminate\Support\Facades\DB;
      use App\Http\Controllers\Admin\AdmissionController;
      $user=DB::table('users')->where('is_admin','1')->get();
      // dd('$user');
      ?>
      <?php if(Auth::user()->is_admin==1): ?>
      <tr>
        <td><a href="<?php echo e(route('status', ['id'=>$admissionform->id])); ?>" type="button" class="mdc-button mdc-button--unelevated filled-button--info mdc-ripple-upgraded"><?php if($admissionform->status == 1): ?> Accepted <?php else: ?> Not Accepted <?php endif; ?></a>
                                    </td>
      </tr>
      <?php else: ?>
      <tr>
        <td><a href="#" type="button"onclick="window.print()" class="mdc-button mdc-button--unelevated filled-button--info mdc-ripple-upgraded">Print</a>
                                    </td>
      </tr>
      <?php endif; ?>
    </tbody>
    
  </table>
  </center>
</div>
</div>



      </div>
    </div>
  </div>
</form>
</div>
</main>

<!-- partial -->
</div>
</div>
</div>
<!-- plugins:js -->
<?php echo $__env->make('admin.admin_layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html> 
<?php /**PATH G:\wamp64\www\laravel\git_lara\vimladeviClgErp\resources\views/admin/admissionViewStudentProfile.blade.php ENDPATH**/ ?>