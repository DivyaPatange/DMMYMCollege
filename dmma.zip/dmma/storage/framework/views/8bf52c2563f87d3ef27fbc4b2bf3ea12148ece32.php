

<?php $__env->startSection('title','Edit Internship Form'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       .hidden{
           display:none;
       }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
    <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">	
                    <strong><?php echo e($message); ?></strong>
            </div>
    <?php endif; ?>
          <form action="<?php echo e(route('updatecertificate', $internshipCertificate->id)); ?>" id="internshipform" enctype="multipart/form-data" method="post">
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Edit Internship Certificate Form</h6>
        <div clas="container p-4">
            <div class="row card-padding">
                <div class="col-md-4">
                     <div class="form-group">
                         <label for="formno">Internship Held Year:</label>
                         <input type="number" name="year" class="form-control" id="year" value="<?php echo e($internshipCertificate->held_year); ?>">
                         <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                </div>
               
                <div class="col-md-4">
                     <div class="form-group">
                         <label for="ayear">Schedule:</label>
                         <input type="text" name="schedule" class="form-control" id="schedule" value="<?php echo e($internshipCertificate->schedule); ?>">
                         <?php $__errorArgs = ['schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                 </div>
                 <div class="col-md-4">
                     <div class="form-group">
                         <label for="course">Duration</label>
                         <input type="text" name="duration" class="form-control" id="duration" value="<?php echo e($internshipCertificate->duration); ?>">
                         <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                 </div>
                 <div class="col-md-4">
                    <div class="form-group">
                        <label for="course">Start Date</label>
                        <input type="date" name="completion_date1" class="form-control" id="completion_date1" value="<?php echo e($internshipCertificate->completion_date1); ?>">
                        <?php $__errorArgs = ['completion_date1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="course">End Date</label>
                        <input type="date" name="completion_date2" class="form-control" id="completion_date2" value="<?php echo e($internshipCertificate->completion_date2); ?>">
                        <?php $__errorArgs = ['completion_date2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="course">Place</label>
                        <input type="text" name="place" class="form-control" id="place" value="<?php echo e($internshipCertificate->place); ?>">
                        <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                 <div class="mdc-layout-grid__cell stretch-card1 mdc-layout-grid__cell--span-12-desktop text-center">
                    <button class="mdc-button mdc-button--unelevated filled-button--success mdc-ripple-upgraded" style="--mdc-ripple-fg-size:56px; --mdc-ripple-fg-scale:1.96936; --mdc-ripple-fg-translate-start:6px, -0.200012px; --mdc-ripple-fg-translate-end:18.8px, -10px;" type="submit" id="submit" name="submit">
                            Update
                    </button>
                  </div>
            </div>
        </div>
        
      </div>
    </div>
  </div>
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\demonstration\resources\views/admin/certificate/editInternshipCertificateList.blade.php ENDPATH**/ ?>