

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--success">
                  <div class="card-inner">
                    <?php

                    use Illuminate\Support\Facades\DB;
                    use App\Http\Controllers\Admin\AdmissionController;

                    $status = DB::table('admissionforms')->where('user_id',Auth::user()->id)->first();
                    
                    //$user_id = DB::table('admissionforms')->select('id')->first()->{'id'}; ?>
                    
                  <?php if(!empty($status)): ?> <?php if($status->status == 1): ?><h5 class="card-title"> Your Admission form is accepted </h5><a href="<?php echo e(route('viewAdmissionForm',$status->id)); ?>"> click here to download </a>
                   <?php else: ?> <h5 class="card-title"> Your admission form is not accepted yet <?php endif; ?> <?php endif; ?></h5>
                     
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--danger">
                  <div class="card-inner">
                    
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--primary">
                  <div class="card-inner">
                    
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--info">
                  <div class="card-inner">
                    
                    </div>
                  </div>
                </div>
              </div>
             
            </div>
          </div>
          <?php $__env->stopSection(); ?>
<?php echo $__env->make('students.student_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\git_lara\vimladeviClgErp\resources\views/students/studentDashboard.blade.php ENDPATH**/ ?>