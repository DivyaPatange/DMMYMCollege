

<?php $__env->startSection('title','Attempt Form'); ?>

<?php $__env->startSection('custom_styles'); ?>
<style>
.hidden {
    display: none;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="mdc-layout-grid">

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>
    
    
        <div class="mdc-layout-grid__inner">
            <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
                <div class="mdc-card p-0">
                    <h6 class="card-title card-padding pb-0">Attempt Certificate Form</h6>
                    <div clas="container p-4">
                        <div class="row card-padding">
                        
                        <div class="col-md-4">
                                <div class="form-group">
                                    <label for="fn">Student Id:</label>
                                    <input type="text" name="studId" class="studId form-control" id="studId">
                                    <?php $__errorArgs = ['studId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger" role="alert-danger">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="mdc-layout-grid__cell stretch-card1 mdc-layout-grid__cell--span-12-desktop text-center"><br>
                                <button
                                    class=" mt-2 mdc-button mdc-button--unelevated filled-button--success mdc-ripple-upgraded"
                                    style="--mdc-ripple-fg-size:56px; --mdc-ripple-fg-scale:1.96936; --mdc-ripple-fg-translate-start:6px, -0.200012px; --mdc-ripple-fg-translate-end:18.8px, -10px;"
                                    type="submit" id="getData" name="submit">
                                    Get Data
                                </button>
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div><br>
        <form action="<?php echo e(url('admin/addAttempt/store')); ?>" id="attempForm" enctype="multipart/form-data"
        method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="mdc-layout-grid__inner">
            <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
                <div class="mdc-card p-0">
                    <h6 class="card-title card-padding pb-0">Attempt Certificate Form</h6>
                    <div clas="container p-4">
                        <input type="hidden" name="studId">
                        <div class="row card-padding">
                            <div class="col-md-6">
                                <div class="form-group" id="fullnamediv">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="course">Date:</label>
                                    <input type="date" name="date" class="date form-control" id="date">
                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="fn">1<sup>st</sup> year Attempt:</label>
                                    <input type="number" name="attempt1st" class="1stattempt form-control" id="1stattempt">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cars">2<sup>nd</sup> Year Attempt:</label>
                                    <input type="number" name="2ndattempt" id="attempt2nd" class="attempt2nd form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cars">3<sup>rd</sup> Year Attempt:</label>
                                    <input type="number" name="3rdattempt" id="attempt3rd" class="3rdattempt form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cars">4<sup>th</sup> Year Attempt:</label>
                                    <input type="number" name="4thattempt" id="attempt4th" class="4thattempt form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cars">1<sup>st</sup> Year Date & Year of Passing:</label>
                                    <input name="yeardatepassing1" type="text" id="yeardatepassing1" class="yeardatepassing1 form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cars">2<sup>nd</sup> Year Date & Year of Passing:</label>
                                    <input name="yeardatepassing2" type="text" id="yeardatepassing2" class="yeardatepassing2 form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cars">3<sup>rd</sup> Year Date & Year of Passing:</label>
                                    <input name="yeardatepassing3" type="text" id="yeardatepassing3" class="yeardatepassing3 form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cars">4<sup>th</sup> Year Date & Year of Passing:</label>
                                    <input name="yeardatepassing4" type="text" id="yeardatepassing4" class="yeardatepassing4 form-control">
                                </div>
                            </div>
                            <div
                                class="mdc-layout-grid__cell stretch-card1 mdc-layout-grid__cell--span-12-desktop text-center">
                                <button
                                    class="mdc-button mdc-button--unelevated filled-button--success mdc-ripple-upgraded"
                                    style="--mdc-ripple-fg-size:56px; --mdc-ripple-fg-scale:1.96936; --mdc-ripple-fg-translate-start:6px, -0.200012px; --mdc-ripple-fg-translate-end:18.8px, -10px;"
                                    type="submit" id="submit" name="submit">
                                    Save
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <!-- </form> -->
</div>
</form>

    <?php $__env->startSection('customjs'); ?>
    <script>
        $(document).ready(function() {
            
            $('#getData').click(function(e) {
            e.preventDefault();
            var studId = $("#studId").val();
            
            $.ajax({
                type: "GET",
                url: "<?php echo e(route('getid')); ?>",
                data:{'studId': studId},
                success: function(data){
                    $('#fullnamediv').html(data);
                    // console.log(data)
                    
                        }
            });

            });
        });
    </script>

    
    <?php $__env->stopSection(); ?>
    
    <?php $__env->stopSection(); ?>     
<?php echo $__env->make('admin.admin_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\git_lara\vimladeviClgErp\resources\views/admin/certificate/attempt/addAttempt.blade.php ENDPATH**/ ?>