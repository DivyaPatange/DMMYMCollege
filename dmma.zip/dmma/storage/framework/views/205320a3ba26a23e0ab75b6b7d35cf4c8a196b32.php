

<?php $__env->startSection('title','Admission Form'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       .hidden{
           display:none;
       }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
    <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">	
                    <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
<form action="<?php echo e(route('student.admissionForm.store')); ?>" enctype="multipart/form-data" method="post">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Admission Form</h6>
        
               <div clas="container p-4">
                   <div class="row card-padding">
                       <div class="col-md-4">
                            
                       </div>
                       <div class="col-md-4">
                            <div class="form-group">
                                <label for="ayear">Academic Year:</label>
                                <input type="number" name="academicyear" class="form-control" id="academicyear">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="course">Course</label>
                                <input type="text" name="course" class="form-control" id="course">
                            </div>
                        </div>
                   </div>
               </div> 
               <div clas="container">
                <div class="row card-padding">
                    <div class="col-md-4">
                         <div class="form-group">
                             <label for="formno">Subject:</label>
                             <input type="text" name="subject" class="form-control" id="subject">
                         </div>
                    </div>
                    <div class="col-md-4">
                         <div class="form-group">
                             <label for="ayear">Admission Year:</label>
                             <input type="text" name="admissionyear" class="form-control" id="admissionyear">
                         </div>
                     </div>
                     <div class="col-md-4">
                         <div class="form-group">
                             <label for="course">Admission Date</label>
                             <input type="date" name="admissiondate" class="form-control" id="admissiondate">
                         </div>
                     </div>
                </div>
            </div>
            <div clas="container">
                <div class="row card-padding">
                    <div class="col-md-4">
                         <div class="form-group">
                             <label for="formno">Admitted Category:</label>
                             <input type="text" name="admittedcategory" class="form-control" id="admittedcategory">
                         </div>
                    </div>
                </div>
            </div> 
      </div>
    </div>
  </div>
  
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <p class="card-title card-padding pb-0"><b>Personal Details</b></p>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-4">
                     <div class="form-group">
                         <label for="formno">First Name:</label>
                         <input type="text" name="firstname" class="form-control" id="firstname">
                     </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="middlename">Middle Name:</label>
                        <input type="text" name="middlename" class="form-control" id="middlename">
                    </div>
               </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Last Name:</label>
                        <input type="text" name="lastname" class="form-control" id="lastname">
                    </div>
                </div>
            </div>
        </div>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-3">
                     <div class="form-group">
                         <label for="formno">Father Name:</label>
                         <input type="text" name="fathername" class="form-control" id="father">
                     </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Father's Occupation:</label>
                        <input type="text" name="fatheroccu" class="form-control" id="fatheroccu">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="middlename">Mother Name:</label>
                        <input type="text" name="mothername" class="form-control" id="mother">
                    </div>
               </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Mother Occupation:</label>
                        <input type="text" name="motheroccu" class="form-control" id="motheroccu">
                    </div>
                </div>
            </div>
        </div>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-3">
                     <div class="form-group">
                         <label for="dob">DOB</label>
                         <input type="date" name="dob" class="form-control" id="dob">
                     </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">City of Birth</label>
                        <input type="text" name="birthcity" class="form-control" id="birthcity">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="middlename">District of Birth:</label>
                        <input type="text" name="birthdistrict" class="form-control" id="birthdistrict">
                    </div>
               </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">State of Birth:</label>
                        <input type="text" name="birthstate" class="form-control" id="birthstate">
                    </div>
                </div>
            </div>
        </div>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-3">
                     <div class="form-group">
                         <label for="dob">Nationality</label>
                         <input type="text" name="nationality" class="form-control" id="nationality">
                     </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Religion</label>
                        <input type="text" name="religion" class="form-control" id="religion">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="middlename">Caste:</label>
                        <input type="text" name="caste" class="form-control" id="caste">
                    </div>
               </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Caste Category:</label>
                        <input type="text" name="castecategory" class="form-control" id="castecategory">
                    </div>
                </div>
            </div>
        </div>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-4">
                     <div class="form-group">
                         <label for="gender">Gender</label><br>
                         <label class="radio-inline"><input type="radio" name="gender" value="Male">Male</label>
                        <label class="radio-inline"><input type="radio" name="gender" value="Female">Female</label>
                        <label class="radio-inline"><input type="radio" name="gender" value="Other">&nbsp;Other</label>
                     </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">UID</label>
                        <input type="text" name="uid" class="form-control" id="uid">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="middlename">Voter Id:</label>
                        <input type="text" name="voterid" class="form-control" id="voterid">
                    </div>
               </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <p class="card-title card-padding pb-0"><b>Address Details</b></p>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Present Address</label>
                        <textarea class="form-control" rows="2" name="presentaddress" id="presentaddress"></textarea>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Present City</label>
                        <input type="text" name="presentcity" class="form-control" id="presentcity">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="middlename">Present State:</label>
                        <input type="text" name="presentstate" class="form-control" id="presentstate">
                    </div>
               </div>
            </div>
        </div>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Permanent Address</label>
                        <textarea class="form-control" rows="2" name="permanentaddress" id="permanentaddress"></textarea>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Permanent City</label>
                        <input type="text" name="permanentcity" class="form-control" id="permanentcity">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="middlename">Permanent State:</label>
                        <input type="text" name="permanentstate" class="form-control" id="permanentstate">
                    </div>
               </div>
            </div>
        </div>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="formno">Student Contact No.</label>
                        <input type="text" name="studcontact" class="form-control" id="Studcontact">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="formno">Student Email</label>
                        <input type="email" name="studemail" class="form-control" id="studemail">
                    </div>
                </div>
            </div>
        </div>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Father's Contact No.</label>
                        <input type="text" name="fathercontact" class="form-control" id="fathercontact">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Father's Email</label>
                        <input type="email" name="fatheremail" class="form-control" id="fatheremail">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Mother's Contact No.</label>
                        <input type="text" name="mothercontact" class="form-control" id="mothercontact">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">mother's Email</label>
                        <input type="email" name="maotheremail" class="form-control" id="motheremail">
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <p class="card-title card-padding pb-0"><b>Last School Details</b></p>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Last College Attended:</label>
                        <input type="text" name="lastclgattended" class="form-control" id="lastcollege">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">College State</label>
                        <input type="text" name="clgstate" class="form-control" id="collegestate">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">College City</label>
                        <input type="text" name="clgcity" class="form-control" id="collegecity">
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <p class="card-title card-padding pb-0"><b>HSSC Details</b></p>
        <div clas="container">
            <div class="row card-padding">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">12th Board:</label>
                        <input type="text" name="twelvethboard" class="form-control" id="twelthboard">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Passing Year</label>
                        <input type="text" name="passingyear" class="form-control" id="passingyear">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="formno">Seat Number</label>
                        <input type="text" name="seatno" class="form-control" id="seatnumber">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="formno">Certificate Number</label>
                        <input type="text" name="certificateno" class="form-control" id="certificatenumber">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="formno">Percentage</label>
                        <input type="text" name="percentage" class="form-control" id="percentage">
                    </div>
                </div>
            </div>
            <div class="row card-padding">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Aggregate</label>
                        <input type="text" name="aggregate" class="form-control" id="aggregate">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Physics Marks</label>
                        <input type="number" name="physicsmarks" class="form-control" id="physicsmarks">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Chemistry Marks</label>
                        <input type="number" name="chemistrymarks" class="form-control" id="chemistry">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Biology Marks</label>
                        <input type="number" name="biologymarks" class="form-control" id="biology">
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  
  

  
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <p class="card-title card-padding pb-0">NEET Exam Details</p>
        <div class="container">
            <div class="row card-padding">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">NEET Marks Obtained</label>
                        <input type="number" name="neetmarksobtained" class="form-control" id="neetmarks">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">NEET Marks Out of:</label>
                        <input type="number" name="neetoutoff" class="form-control" id="outof">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">NEET Year</label>
                        <input type="number" name="neetyear" class="form-control" id="neetyear">
                    </div>
                </div>
            </div>
            <div class="row card-padding">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Quota Alloted</label>
                        <input type="text" name="quotaalloted" class="form-control" id="quota">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Scheme</label>
                        <input type="text" name="scheme" class="form-control" id="scheme">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="formno">Dir sec Year</label>
                        <input type="text" name="dirsecyear" class="form-control" id="direct">
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <p class="card-title card-padding pb-0"><b>Previous Exam Details</b></p>
        <div class="container">
            <div class="row card-padding">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="formno">College Address</label>
                        <input type="text" name="clgaddress" class="form-control" id="clgaddress">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="formno">College Code</label>
                        <input type="text" name="clgcode" class="form-control" id="clgcode">
                    </div>
                </div>
            </div>
            <div class="row card-padding">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Obtained marks</label>
                        <input type="text" name="obtainedmarks" class="form-control" id="obtmarks">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Total Marks</label>
                        <input type="text" name="totalmarks" class="form-control" id="totalmarks">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Previous Year Result</label>
                        <input type="text" name="previousyearresult" class="form-control" id="preresult">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="formno">Previous Exam Percentage</label>
                        <input type="text" name="previousexampercentage" class="form-control" id="preexresult">
                    </div>
                </div>
            </div>
            <div class="mdc-layout-grid__cell stretch-card1 mdc-layout-grid__cell--span-12-desktop text-center">
                <button class="mdc-button mdc-button--unelevated filled-button--success mdc-ripple-upgraded" style="--mdc-ripple-fg-size:56px; --mdc-ripple-fg-scale:1.96936; --mdc-ripple-fg-translate-start:6px, -0.200012px; --mdc-ripple-fg-translate-end:18.8px, -10px;" type="submit" name="submit">
                        Save
                </button>
              </div>
        </div>
      </div>
    </div>
  </div>
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.student_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\git_lara\vimladeviClgErp\resources\views/students/admissionForm.blade.php ENDPATH**/ ?>