<link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- fontawsome -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/jvectormap/jquery-jvectormap.css')); ?>">
  <!-- End plugin css for this page -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/css/demo/style.css')); ?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo e(URL::asset('brandAssets/images/favicon.png')); ?>" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css"><?php /**PATH G:\wamp64\www\laravel\dmma\resources\views/admin/admin_layouts/link.blade.php ENDPATH**/ ?>