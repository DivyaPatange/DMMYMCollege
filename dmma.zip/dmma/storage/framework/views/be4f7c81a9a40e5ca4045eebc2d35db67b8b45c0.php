

<?php $__env->startSection('title','Admission List'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       .hidden{
           display:none;
       }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Admission List</h6>
        <div class="table-responsive p-4">
            <table class="table table-hoverable" id="datatable" >
              <thead>
                <tr>
                  
                  <th class="text-center">ID</th>
                  <th class="text-center">FORM NO.</th>
                  <th class="text-center">NAME</th>
                  <th class="text-center">COURSE</th>
                  <th class="text-center">ADMISSION YEAR</th>
                  <th class="text-center">STATUS</th>
                  <th class="text-center">ACTION</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $admissionform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td class="text-center"><?php echo e(++$key); ?></td>
                                <td class="text-center"><?php echo e($a->formno); ?></td>
                                <td class="text-center"><?php echo e($a->firstname); ?>&nbsp;<?php echo e($a->middlename); ?> <?php echo e($a->fathername); ?></td>
                                <td class="text-center"><?php echo e($a->course); ?></td>
                                <td class="text-center"><?php echo e($a->admissionyear); ?></td>
                                <td class="text-center"><?php if($a->status == 0): ?>Not Accepted <?php else: ?> Accepted <?php endif; ?></td>
                                <td class="text-center">
                                     <a href="<?php echo e(route('viewAdmissionForm', ['id'=>$a->id])); ?>" type="button" class="mdc-button mdc-button--unelevated filled-button--info mdc-ripple-upgraded">View</a>
                                    
                                   
                                    
                                    
                                  
                                </td>
                                
                                
                                
                                
                                
                                
                                  
                                
                              </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      </div>
    </div>
  </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\demonstration\resources\views/admin/admissionList.blade.php ENDPATH**/ ?>