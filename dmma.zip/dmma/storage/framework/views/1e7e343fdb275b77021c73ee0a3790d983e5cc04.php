<footer>
          <div class="mdc-layout-grid">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card1 mdc-layout-grid__cell--span-12-desktop">
              <h6 class="text-center">
                        © Copyright <strong>Vimladevi Ayurvedic Medical College</strong>. All Rights Reserved
</h6>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
              <p class="ml-0 mr-0 mt-0 p-0 text-left"> Designed by<b> <a href="https://iceico.in" target="_blank">ICEICO Technologies Pvt. Ltd.</a></b></p>
                <!-- <span class="tx-14">Copyright © 2019 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span> -->
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop d-flex justify-content-end">
              <p class="ml-0 mr-0 mt-0 p-0 text-right">Powered by   <img src="<?php echo e(asset('assets/frontend/img/logo/iceico group.png')); ?>" style="height:30px;">  ICEICO Group</p>
              </div>
            </div>
          </div>
        </footer><?php /**PATH G:\wamp64\www\laravel\dmma\resources\views/students/student_layouts/footer.blade.php ENDPATH**/ ?>