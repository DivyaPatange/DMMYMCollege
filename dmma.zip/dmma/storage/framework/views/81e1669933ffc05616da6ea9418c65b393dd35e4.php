

<?php $__env->startSection('title','Internship Certificate List'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       .hidden{
           display:none;
       }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Offline Internship Certificate List</h6>
        <div class="table-responsive p-4">
            <table class="table table-hoverable text-center" id="datatable" >
              <thead>
                <tr>
                  
                  <th class="text-center">ID</th>
                  <th class="text-center">STUDENT NAME</th>
                  <th class="text-center">SESSION</th>
                  <th class="text-center">DATE</th>
                  <th class="text-center">ACTION</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e(++$key); ?></td>
                                <td class="text-center"><?php echo e($dt->firstname); ?> &nbsp;<?php echo e($dt->middlename); ?>&nbsp;<?php echo e($dt->lastname); ?></td>
                            <td class="text-center"><?php echo e($dt->sessonseason); ?>- <?php echo e($dt->sessionyear); ?></td>
                            <td class="text-center"><?php echo e($dt->date); ?></td>
                                <td class="text-center">
                                <a href="<?php echo e(route('internship.certificate',['id'=>$dt->offline_id])); ?>" type="button" class="text-dark" title="view"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('internship.editOffline',['id'=>$dt->offline_id])); ?>" type="button" class="text-dark" title="edit"><i class="fa fa-edit"></i></a>
                                     <a href="javascript:void(0)" onclick="$(this).parent().find('form').submit()" type="button" class="text-dark" title="delete"><i class="fa fa-trash"></i></a>
                                      <form action="<?php echo e(route('deleteOfflineintern',['id'=>$dt->id = $dt->offline_id])); ?>" method="post"> 
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                     </form>
                                     
                    
                                    
                                </td>
                            </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      </div>
    </div>
  </div>
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\dmma\resources\views/admin/certificate/internship/offlineInternshipList.blade.php ENDPATH**/ ?>