<link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/vendors/jvectormap/jquery-jvectormap.css')); ?>">
  <!-- End plugin css for this page -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('brandAssets/css/demo/style.css')); ?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo e(URL::asset('brandAssets/images/favicon.png')); ?>" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"><?php /**PATH G:\wamp64\www\laravel\git_lara\vimladeviClgErp\resources\views/students/student_layouts/link.blade.php ENDPATH**/ ?>