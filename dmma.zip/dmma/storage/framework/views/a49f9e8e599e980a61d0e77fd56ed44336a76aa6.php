

<?php $__env->startSection('title','Bonafide Certificate List'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       .hidden{
           display:none;
       }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Bonafide Certificate List</h6>
        <div class="table-responsive p-4">
            <table class="table table-hoverable text-center" id="datatable" >
              <thead>
                <tr>
                  
                  <th class="text-center">ID</th>
                  <th class="text-center">STUDENT NAME</th>
                  <th class="text-center">FATHER NAME</th>
                  <th class="text-center">CLASS</th>
                  <th class="text-center">ACADEMIC YEAR</th>
                  <th class="text-center">DATE OF ADMISSION</th>
                  <th class="text-center">DOB</th>
                  <th class="text-center">DATE</th>
                  <th class="text-center">ACTION</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $offlinebonafide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e(++$key); ?></td>
                                <td class="text-center"><?php echo e($b->fullname); ?></td>
                            <td class="text-center"><?php echo e($b->fathername); ?></td>
                            <td class="text-center"><?php echo e($b->class); ?></td>
                            <td class="text-center"><?php echo e($b->academicyear); ?></td>
                            <td class="text-center"><?php echo e($b->admissiondate); ?></td>
                            <td class="text-center"><?php echo e($b->dob); ?></td>
                            <td class="text-center"><?php echo e($b->date); ?></td>
                                <td class="text-center">
                                <a href="<?php echo e(route('bonafide.certificate',['id'=>$b->id])); ?>" type="button" class="text-dark" title="view"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('bonafide.editbonafide',['id'=>$b->id])); ?>" type="button" class="text-dark" title="edit"><i class="fa fa-edit"></i></a>
                                     <a href="javascript:void(0)" onclick="$(this).parent().find('form').submit()" type="button" class="text-dark" title="delete"><i class="fa fa-trash"></i></a>
                                      <form action="<?php echo e(route('deleteOfflinebonafide',['id'=>$b->id])); ?>" method="post"> 
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                     </form>
                                     
                    
                                    
                                </td>
                            </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      </div>
    </div>
  </div>
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\git_lara\vimladeviClgErp\resources\views/admin/certificate/bonafide/bonafideList.blade.php ENDPATH**/ ?>