

<?php $__env->startSection('title','Internship Certificate Request List'); ?>

<?php $__env->startSection('custom_styles'); ?>
    <style>
       .hidden{
           display:none;
       }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid">
  <div class="mdc-layout-grid__inner">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Internship Certificate Request List</h6>
        <div class="table-responsive p-4">
            <table class="table table-hoverable text-center" id="datatable" >
              <thead>
                <tr>
                  
                  <th class="text-center">ID</th>
                  <th class="text-center">STUDENT NAME</th>
                  <th class="text-center">ACTION</th>
                  
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $internshiprequestjoin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e(++$key); ?></td>
                                <td class="text-center"><?php echo e($ir->firstname); ?> &nbsp;<?php echo e($ir->middlename); ?>&nbsp;<?php echo e($ir->lastname); ?></td>
                                
                                <td class="text-center">
                                     <a href="<?php echo e(route('generateCertificate', ['id'=>$ir->id])); ?>" type="button" class="mdc-button mdc-button--unelevated filled-button--info mdc-ripple-upgraded">Generate</a>
                                    
                                   
                                    
                                    
                                  
                                </td>
                            </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      </div>
    </div>
  </div>
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\laravel\git_lara\vimladeviClgErp\resources\views/admin/certificate/internshipRequestList.blade.php ENDPATH**/ ?>